package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.BoardScreen
import com.example.ui.screens.MainMenuScreen
import com.example.ui.screens.MapScreen
import com.example.ui.screens.TerminalScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TerminalBackground

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = TerminalBackground
                ) {
                    RetroAppNavigation()
                }
            }
        }
    }
}

@Composable
fun RetroAppNavigation() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "main_menu") {
        composable("main_menu") {
            MainMenuScreen(
                onNewGameClick = { navController.navigate("terminal") },
                onContinueClick = { navController.navigate("terminal") }
            )
        }
        composable("terminal") {
            TerminalScreen(
                onNavigateMap = { navController.navigate("map") },
                onNavigateBoard = { navController.navigate("board") }
            )
        }
        composable("board") {
            BoardScreen(
                onBack = { navController.popBackStack() }
            )
        }
        composable("map") {
            MapScreen(
                onBack = { navController.popBackStack() }
            )
        }
    }
}
