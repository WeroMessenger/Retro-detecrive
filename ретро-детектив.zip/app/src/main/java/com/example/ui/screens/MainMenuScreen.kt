package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.ScreenGlassOverlay
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalGreen

@Composable
fun MainMenuScreen(
    onNewGameClick: () -> Unit,
    onContinueClick: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
        // Background Image
        Image(
            painter = painterResource(id = R.drawable.img_menu_bg),
            contentDescription = "City background",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        
        // Scanline overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(ScreenGlassOverlay)
        )
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(48.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = "RETRO DETECTIVE",
                style = MaterialTheme.typography.titleLarge,
                color = TerminalCyan,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                text = "OSINT TERMINAL v1.0",
                style = MaterialTheme.typography.bodyMedium,
                color = TerminalGreen,
                modifier = Modifier.padding(bottom = 48.dp)
            )
            
            MenuButton("НОВАЯ ИГРА", onClick = onNewGameClick)
            Spacer(modifier = Modifier.height(16.dp))
            MenuButton("ПРОДОЛЖИТЬ", onClick = onContinueClick)
            Spacer(modifier = Modifier.height(16.dp))
            MenuButton("НАСТРОЙКИ", onClick = { /* TODO */ })
            Spacer(modifier = Modifier.height(16.dp))
            MenuButton("ВЫХОД", onClick = { /* TODO exit */ })
        }
    }
}

@Composable
fun MenuButton(text: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .width(250.dp)
            .border(1.dp, TerminalGreen)
            .background(Color.Black.copy(alpha = 0.5f))
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Text(
            text = "> $text",
            style = MaterialTheme.typography.bodyLarge,
            color = TerminalGreen
        )
    }
}
