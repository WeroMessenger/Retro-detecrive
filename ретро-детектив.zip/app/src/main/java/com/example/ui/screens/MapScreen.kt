package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.MapPointColor
import com.example.ui.theme.TerminalBackground
import com.example.ui.theme.TerminalGreen

@Composable
fun MapScreen(onBack: () -> Unit) {
    var selectedLocation by remember { mutableStateOf<String?>(null) }
    
    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.img_map_bg),
            contentDescription = "Map background",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        
        // Locations
        MapLocation(x = 0.3f, y = 0.4f, name = "СТАРЫЙ ЗАВОД", onSelect = { selectedLocation = it })
        MapLocation(x = 0.6f, y = 0.2f, name = "МЕТРО", onSelect = { selectedLocation = it })
        MapLocation(x = 0.5f, y = 0.7f, name = "ПОЛИЦЕЙСКИЙ УЧАСТОК", onSelect = { selectedLocation = it })
        MapLocation(x = 0.8f, y = 0.6f, name = "Ж/Д СТАНЦИЯ", onSelect = { selectedLocation = it })
        
        Button(
            onClick = onBack,
            modifier = Modifier.align(Alignment.TopStart).padding(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = TerminalBackground)
        ) {
            Text("< НАЗАД", color = TerminalGreen, style = MaterialTheme.typography.bodyLarge)
        }
        
        if (selectedLocation != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(32.dp)
                    .background(TerminalBackground.copy(alpha = 0.9f))
                    .border(2.dp, TerminalGreen)
                    .padding(24.dp)
            ) {
                Column {
                    Text("ЛОКАЦИЯ: $selectedLocation", color = MapPointColor, style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("СТАТУС: ИССЛЕДУЕТСЯ...", color = TerminalGreen, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

@Composable
fun BoxScope.MapLocation(x: Float, y: Float, name: String, onSelect: (String) -> Unit) {
    Box(
        modifier = Modifier
            .align(Alignment.TopStart)
            .offset(
                x = (x * 800).dp, // Crude approximation
                y = (y * 400).dp
            )
            .size(16.dp)
            .background(MapPointColor, CircleShape)
            .clickable { onSelect(name) }
    )
    
    Text(
        text = name,
        modifier = Modifier
            .align(Alignment.TopStart)
            .offset(
                 x = (x * 800 - 40).dp,
                 y = (y * 400 + 20).dp
            )
            .background(Color.Black.copy(alpha = 0.6f))
            .padding(4.dp),
        color = MapPointColor,
        style = MaterialTheme.typography.labelSmall
    )
}
