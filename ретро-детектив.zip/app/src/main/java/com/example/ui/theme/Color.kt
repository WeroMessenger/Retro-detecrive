package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TerminalBackground = Color(0xFF0C1410)
val TerminalGreen = Color(0xFF4AF626)
val TerminalDarkGreen = Color(0xFF1E5618)
val TerminalCyan = Color(0xFF00FFCC)
val TerminalRed = Color(0xFFFF3333)
val MapPointColor = Color(0xFFFFCC00)
val ScreenGlassOverlay = Color(0x15FFFFFF)
