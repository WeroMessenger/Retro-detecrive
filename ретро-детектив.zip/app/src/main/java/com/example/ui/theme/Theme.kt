package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val RetroDarkColorScheme = darkColorScheme(
    primary = TerminalGreen,
    secondary = TerminalCyan,
    background = TerminalBackground,
    surface = TerminalBackground,
    onPrimary = TerminalBackground,
    onSecondary = TerminalBackground,
    onBackground = TerminalGreen,
    onSurface = TerminalGreen,
    surfaceVariant = TerminalDarkGreen,
    onSurfaceVariant = TerminalGreen,
    error = TerminalRed,
    onError = TerminalBackground
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force dark theme
    dynamicColor: Boolean = false, // Force retro colors
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = RetroDarkColorScheme,
        typography = Typography,
        content = content
    )
}
