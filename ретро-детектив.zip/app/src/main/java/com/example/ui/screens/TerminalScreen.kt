package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalBackground
import com.example.ui.theme.TerminalDarkGreen
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TerminalScreen(
    onNavigateMap: () -> Unit,
    onNavigateBoard: () -> Unit
) {
    var command by remember { mutableStateOf("") }
    var outputLog by remember { mutableStateOf(listOf("СИСТЕМА ЗАПУЩЕНА...", "АВТОРИЗАЦИЯ УСПЕШНА.", "ВВЕДИТЕ 'help' ИЛИ ИМЯ ПОДОЗРЕВАЕМОГО ДЛЯ ПОИСКА")) }
    
    Row(modifier = Modifier.fillMaxSize().background(TerminalBackground)) {
        // Sidebar commands
        Column(
            modifier = Modifier
                .width(200.dp)
                .fillMaxHeight()
                .border(2.dp, TerminalDarkGreen)
                .padding(16.dp)
        ) {
            Text("[ БАЗА ДАННЫХ ]", color = TerminalCyan, style = MaterialTheme.typography.labelLarge)
            Spacer(modifier = Modifier.height(24.dp))
            SidebarButton("МАРШРУТЫ (КАРТА)", onClick = onNavigateMap)
            Spacer(modifier = Modifier.height(12.dp))
            SidebarButton("УЛИКИ (ДОСКА)", onClick = onNavigateBoard)
            Spacer(modifier = Modifier.height(12.dp))
            SidebarButton("ПОЧТА", onClick = { outputLog = outputLog + "> Нет новых сообщений." })
            Spacer(modifier = Modifier.weight(1f))
            Image(
                painter = painterResource(R.drawable.img_suspect),
                contentDescription = "Suspect",
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .border(1.dp, TerminalGreen)
            )
            Text("ПОСЛЕДНИЙ ЗАПРОС", color = TerminalGreen, style = MaterialTheme.typography.labelSmall)
        }
        
        // Terminal Window
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(16.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                reverseLayout = true
            ) {
                items(outputLog.reversed()) { log ->
                    Text(text = log, color = TerminalGreen, style = MaterialTheme.typography.bodyLarge)
                    Spacer(modifier = Modifier.height(4.dp))
                }
            }
            
            HorizontalDivider(color = TerminalDarkGreen, modifier = Modifier.padding(vertical = 8.dp))
            
            Row(modifier = Modifier.fillMaxWidth()) {
                Text("> ", color = TerminalCyan, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 4.dp))
                TextField(
                    value = command,
                    onValueChange = { command = it.uppercase() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        cursorColor = TerminalCyan,
                        focusedTextColor = TerminalGreen,
                        unfocusedTextColor = TerminalGreen
                    ),
                    textStyle = MaterialTheme.typography.titleMedium,
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(
                        onSend = {
                            if (command.isNotBlank()) {
                                val newLog = when(command.trim()) {
                                    "HELP" -> listOf("> HELP", "ДОСТУПНЫЕ КОМАНДЫ:", "JOHN DOE - данные", "ARCHIVE - архивы дел")
                                    "JOHN DOE" -> listOf("> JOHN DOE", "ИМЯ: JOHN DOE", "СТАТУС: ПРОПАВШИЙ БЕЗ ВЕСТИ", "ПОСЛЕДНЕЕ МЕСТО: СТАРЫЙ ЗАВОД")
                                    else -> listOf("> $command", "СОВПАДЕНИЙ НЕ НАЙДЕНО.")
                                }
                                outputLog = outputLog + newLog
                                command = ""
                            }
                        }
                    )
                )
            }
        }
    }
}

@Composable
fun SidebarButton(text: String, onClick: () -> Unit) {
    Text(
        text = "> $text",
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        color = TerminalGreen,
        style = MaterialTheme.typography.bodyMedium
    )
}
