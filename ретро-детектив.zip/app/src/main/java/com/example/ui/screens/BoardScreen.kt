package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.ui.theme.TerminalBackground
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalRed
import kotlin.math.roundToInt

@Composable
fun BoardScreen(onBack: () -> Unit) {
    var node1Pos by remember { mutableStateOf(Offset(200f, 200f)) }
    var node2Pos by remember { mutableStateOf(Offset(600f, 300f)) }
    var node3Pos by remember { mutableStateOf(Offset(300f, 500f)) }

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF111111))) {
        // Draw red threads
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawLine(
                color = TerminalRed,
                start = node1Pos + Offset(150f, 100f),
                end = node2Pos + Offset(150f, 100f),
                strokeWidth = 4f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
            )
            drawLine(
                color = TerminalRed,
                start = node1Pos + Offset(150f, 100f),
                end = node3Pos + Offset(150f, 100f),
                strokeWidth = 4f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
            )
        }

        // Draggable Nodes
        DraggableNote(
            text = "PHOTO: JOHN DOE",
            position = node1Pos,
            onPositionChange = { node1Pos += it }
        )
        DraggableNote(
            text = "МЕСТО: СТАРЫЙ ЗАВОД",
            position = node2Pos,
            onPositionChange = { node2Pos += it }
        )
        DraggableNote(
            text = "УЛИКА: ОРУЖИЕ",
            position = node3Pos,
            onPositionChange = { node3Pos += it }
        )
        
        Button(
            onClick = onBack,
            modifier = Modifier.align(Alignment.TopStart).padding(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = TerminalBackground)
        ) {
            Text("< НАЗАД", color = TerminalGreen, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

@Composable
fun DraggableNote(
    text: String,
    position: Offset,
    onPositionChange: (Offset) -> Unit
) {
    Box(
        modifier = Modifier
            .offset { IntOffset(position.x.roundToInt(), position.y.roundToInt()) }
            .width(200.dp)
            .height(150.dp)
            .background(Color(0xFF222222), CutCornerShape(8.dp))
            .border(2.dp, TerminalGreen, CutCornerShape(8.dp))
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onPositionChange(dragAmount)
                }
            }
            .padding(16.dp)
    ) {
        Text(text, color = TerminalGreen, style = MaterialTheme.typography.bodyMedium)
    }
}
